<?php
symlink('/home/uforumco/uforum/storage/app/public', '/home/uforumco/public_html/storage');
?>