function displayLogin()
{
		document.getElementById('loginForm').style.display = "block";
		document.getElementById('signinForm').style.display = "none";

}

function displaySignIn()
{
	document.getElementById('signinForm').style.display = "block";
	document.getElementById('loginForm').style.display = "none";
}

function displayEditAvatar()
{
	document.getElementById('edit_avatar').style.display = "block";
}