function addBook()
{
	document.getElementById('book_form').style.display = 'block';
}