function addTopic()
{
	document.getElementById('topic_form').style.display = "block";
}
