function addRes()
{
	document.getElementById('res_form').style.display = 'block';
}